#!/usr/bin/env python3

from brain_games import cli


def main():
    cli.user_welcome()
